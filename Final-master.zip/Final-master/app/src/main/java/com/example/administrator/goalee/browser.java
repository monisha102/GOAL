package com.example.administrator.goalee;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class browser extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_browser);
    }
}
